package test;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class QuartzTest2 implements Job {

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		long now = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
		String nowDateTime = sdf.format(new Date(now));
		
		System.out.println("#########################################################################2");
	    System.out.println("NowDateTime [" + nowDateTime + "] : delMemberSchedule.delMemberOneYear()2");
	    System.out.println("#########################################################################2");
		
	}
	
}
