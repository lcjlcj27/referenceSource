package test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzTest {
	private SchedulerFactory schedFact;
	private Scheduler sched;

	
	/* **************** 사용 방법 *********************************************************** 
	  *  JOB 1개당 JobDetail / CronTrigger /  sched.scheduleJob 생성
	  *
	  *  Job1 생성 (JobDetail) :  (Parameter : 1.Job Name, 2.Job Group Name, 3.Job Class);
	  *  Trigger1 생성(CronTrigger) :  (Parameter : 1.Trigger Name, 2.Trigger Group Name, 3.Cron Expression);
	  *  스케줄 실행(scheduleJob) : ( JobDetail, CronTrigger );
	  *
	  * (참고) 아래의 표는 CronTrigger 에서 작업주기를 설정하는 식의 예와 설명 (3.Cron Expression)
	  *   순서
	  *   1. Seconds (0-59) - * /
	  *   2. Minutes (0-59)  - * /
	  *   3. Hours (0-23)  - * /
	  *   4. Day-of-month (1-31) - * ? / L W C
	  *   5. Month (1-12 or JAN-DEC) - * /
	  *   6. Day-of-week (1-7 or SUN-SAT) - * ? / L C #
	  *   7. Year (optional, empty, 1970-2099) - * /
	  * *********************************************************************************** */
	private void schedulerInit() {
		try {
			schedFact = new StdSchedulerFactory();
			sched = schedFact.getScheduler();
			sched.start();
			
			long now = System.currentTimeMillis();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
			String nowTime = sdf.format(new Date(now));
			System.out.println("start = " + nowTime);
			
			JobDetail jobdetail2 = new JobDetail("testJob2", "group2", QuartzTest2.class);
			CronTrigger trigger2 = new CronTrigger("testTrigger2", "group2", "13 * * * * ?");		// 매일 현재 시각이 13초인경우 실행
			// 현재 시간이 기준 현재시간이 해당 조건일 경우 실행
			sched.scheduleJob(jobdetail2, trigger2);
			
			JobDetail jobdetail3 = new JobDetail("testJob3", "group3", QuartzTest3.class);
			CronTrigger trigger3 = new CronTrigger("testTrigger3", "group3", "27 28 * * * ?");		// 매일 현재 시각이 28분 27초인경우 실행
			sched.scheduleJob(jobdetail3, trigger3);
			
			
		} catch (SchedulerException e) {
			System.out.println("SchedulerException = " + e.getMessage());
		} catch (ParseException e) {
			System.out.println("ParseException = " + e.getMessage());
		}
		
	}

	public static void main(String[] args) {
		QuartzTest qt = new QuartzTest();
		qt.schedulerInit();
	}

}
